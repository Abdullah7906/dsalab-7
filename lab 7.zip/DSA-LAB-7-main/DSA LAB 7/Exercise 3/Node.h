class Node {
public:
    int data;
    Node* next;
    Node(int val);
};
