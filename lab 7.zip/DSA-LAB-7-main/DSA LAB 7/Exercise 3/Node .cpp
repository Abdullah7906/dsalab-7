#include "Node.h"

Node::Node(int val) {
    data = val;
    next = nullptr;
}
